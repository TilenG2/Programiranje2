public class program{
	public static void main(String[] args){
	
	}
}